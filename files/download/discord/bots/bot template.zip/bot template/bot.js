require('dotenv').config(); // imports .env

const Discord = require('discord.js') // imports discord.js from 'node_modules'
const client = new Discord.Client({ intents: ["GUILDS", "GUILD_MESSAGES"] }) // declares the intents. You wont ever need to chnage this
const PREFIX = "!" // you can change the bot prefix with this, currently the bot prefix is '!'

client.once("ready", () => {
    console.log(`Logged in as ${client.user.tag}!`); // sends a message to the console when the bot goes online
});


client.on("message", msg => { // when the user sends a message
  if (msg.author.bot) return // if the commmand in executed by the bot, return
  if (msg.content.startsWith(PREFIX)) { //if command starts with prefix
    const [CMD_NAME, ...args] = msg.content // create var call cmd_name with args and make it = to msg.content
      .trim()
      .substring(PREFIX.length)
      .split(/\s+/)
    } 
    // here are some template commands
    if (CMD_NAME === 'command') { // if user sends {prefix}{user message contents} cmd_name = user message contents
      msg.channel.send("This is the {your server name here} bot.") // sends a message in discord
    } else if (CMD_NAME === 'hi') {
      msg.channel.send(`Hi ${msg.author.toString()}! I am the {your server name here} bot.`) // sends a message in discord with your name in it
    } else if (CMD_NAME === 'reload') {
      Discord.crash.CrashBot(`CrashBotOn{prefix}Reload`) // this line makes no sense making the bot crash and restart, updating it if you made changes  
    } else if (CMD_NAME === 'help') {
      // your help code here
    }
});

client.login(process.env.DISCORD_BOT_TOKEN); // takes token listed form .env and turns it into a string making the token private if you upload it to code sharing sites
